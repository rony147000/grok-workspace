import { createFileRoute } from "@tanstack/react-router";
import { SignalTerminal } from "@/components/signal-terminal";

export const Route = createFileRoute("/")({ component: Home });

function Home() {
  return <SignalTerminal />;
}

import { useQuery } from "@tanstack/react-query";
import {
  Activity,
  AlertTriangle,
  Clock3,
  RefreshCw,
  Shield,
  Star,
  Target,
  TrendingDown,
  TrendingUp,
} from "lucide-react";
import { useEffect, useMemo } from "react";
import { toast } from "sonner";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { PriceChart } from "@/components/price-chart";
import { useDesk } from "@/lib/desk";
import { copy, type Lang } from "@/lib/i18n";
import { ASSET_BY_ID, INTERVALS, assetsIn, type Category, type Interval } from "@/lib/market";
import { getAssetSignal, getScanner, type AssetSignalDto, type ScannerRow } from "@/lib/market-fn";
import type { SignalAction } from "@/lib/ta";
import { cn, formatPct, formatPrice, formatTime } from "@/lib/utils";

function actionTone(action: SignalAction): "buy" | "sell" | "hold" {
  if (action === "buy" || action === "strong_buy") return "buy";
  if (action === "sell" || action === "strong_sell") return "sell";
  return "hold";
}

function actionLabel(action: SignalAction, t: (typeof copy)[Lang]) {
  if (action === "strong_buy") return t.strongBuy;
  if (action === "buy") return t.actionBuy;
  if (action === "strong_sell") return t.strongSell;
  if (action === "sell") return t.actionSell;
  return t.actionHold;
}

function heroLabel(action: SignalAction, t: (typeof copy)[Lang]) {
  if (action === "buy" || action === "strong_buy") return t.buy;
  if (action === "sell" || action === "strong_sell") return t.sell;
  return t.hold;
}

function confLabel(n: number, t: (typeof copy)[Lang]) {
  if (n >= 72) return t.high;
  if (n >= 48) return t.medium;
  return t.low;
}

function Mark() {
  return (
    <svg viewBox="0 0 24 24" className="size-6" aria-hidden="true">
      <rect x="3" y="14" width="4" height="7" rx="1" fill="currentColor" />
      <rect x="10" y="9" width="4" height="12" rx="1" fill="currentColor" />
      <rect x="17" y="4" width="4" height="17" rx="1" fill="var(--color-buy)" />
    </svg>
  );
}

export function SignalTerminal() {
  const lang = useDesk((s) => s.lang);
  const category = useDesk((s) => s.category);
  const interval = useDesk((s) => s.interval);
  const selectedId = useDesk((s) => s.selectedId);
  const watchlist = useDesk((s) => s.watchlist);
  const starredOnly = useDesk((s) => s.starredOnly);
  const setLang = useDesk((s) => s.setLang);
  const setCategory = useDesk((s) => s.setCategory);
  const setInterval = useDesk((s) => s.setInterval);
  const setSelectedId = useDesk((s) => s.setSelectedId);
  const toggleWatch = useDesk((s) => s.toggleWatch);
  const setStarredOnly = useDesk((s) => s.setStarredOnly);
  const t = copy[lang];

  const scanner = useQuery({
    queryKey: ["scanner", category, interval],
    queryFn: () => getScanner({ data: { category, interval } }),
    refetchInterval: 45_000,
  });

  const detail = useQuery({
    queryKey: ["signal", selectedId, interval],
    queryFn: () => getAssetSignal({ data: { id: selectedId, interval } }),
    refetchInterval: 30_000,
  });

  const rows = useMemo(() => {
    const list = scanner.data ?? [];
    const filtered = starredOnly ? list.filter((r) => watchlist.includes(r.id)) : list;
    return [...filtered].sort((a, b) => Math.abs(b.score - 50) - Math.abs(a.score - 50));
  }, [scanner.data, starredOnly, watchlist]);

  useEffect(() => {
    const inCat = assetsIn(category).some((a) => a.id === selectedId);
    if (!inCat) {
      const first = assetsIn(category)[0];
      if (first) setSelectedId(first.id);
    }
  }, [category, selectedId, setSelectedId]);

  const asset = ASSET_BY_ID[selectedId];
  const starred = watchlist.includes(selectedId);

  return (
    <div className="min-h-dvh bg-background text-foreground">
      <header className="sticky top-0 z-20 border-b border-border bg-background/90 px-4 py-3 backdrop-blur-sm sm:px-6">
        <div className="mx-auto flex max-w-6xl items-center gap-3">
          <div className="flex min-w-0 items-center gap-2.5">
            <Mark />
            <div className="min-w-0">
              <p className="text-sm font-semibold tracking-tight">{t.app}</p>
              <p className="text-xs text-muted-foreground">{t.tag}</p>
            </div>
          </div>
          <div className="ml-auto flex items-center gap-1.5">
            <div className="hidden items-center rounded-xl bg-card p-1 sm:flex">
              {INTERVALS.map((iv) => (
                <button
                  key={iv}
                  type="button"
                  onClick={() => setInterval(iv)}
                  className={cn(
                    "h-9 min-w-11 rounded-lg px-2.5 font-mono text-xs tabular-nums transition-colors duration-[var(--motion-quick)]",
                    interval === iv ? "bg-elevated text-foreground" : "text-muted-foreground hover:text-foreground",
                  )}
                >
                  {iv}
                </button>
              ))}
            </div>
            <Button
              variant="subtle"
              size="sm"
              onClick={() => setLang(lang === "bn" ? "en" : "bn")}
              aria-label="Language"
            >
              {lang === "bn" ? "EN" : "বাং"}
            </Button>
          </div>
        </div>
        <div className="mx-auto mt-3 flex max-w-6xl gap-1 overflow-x-auto sm:hidden">
          {INTERVALS.map((iv) => (
            <button
              key={iv}
              type="button"
              onClick={() => setInterval(iv)}
              className={cn(
                "h-11 shrink-0 rounded-lg px-3 font-mono text-xs tabular-nums",
                interval === iv ? "bg-elevated text-foreground" : "text-muted-foreground",
              )}
            >
              {iv}
            </button>
          ))}
        </div>
      </header>

      <main className="mx-auto max-w-6xl px-4 py-5 sm:px-6 sm:py-8">
        <div className="mb-5 flex items-start gap-2.5 rounded-2xl bg-card px-4 py-3 shadow-border">
          <AlertTriangle className="mt-0.5 size-4 shrink-0 text-muted-foreground" />
          <p className="text-sm leading-relaxed text-muted-foreground">{t.disclaimer}</p>
        </div>

        <div className="mb-4 flex flex-wrap items-center gap-2">
          {(["crypto", "stock", "metal", "fx"] as Category[]).map((c) => (
            <button
              key={c}
              type="button"
              onClick={() => {
                setCategory(c);
                const first = assetsIn(c)[0];
                if (first) setSelectedId(first.id);
              }}
              className={cn(
                "h-11 rounded-xl px-4 text-sm font-medium transition-colors duration-[var(--motion-quick)]",
                category === c ? "bg-primary text-primary-foreground" : "bg-card text-muted-foreground hover:text-foreground",
              )}
            >
              {t[c]}
            </button>
          ))}
          <button
            type="button"
            onClick={() => setStarredOnly(!starredOnly)}
            className={cn(
              "ml-auto h-11 rounded-xl px-3 text-sm",
              starredOnly ? "bg-elevated text-foreground" : "text-muted-foreground",
            )}
          >
            {t.starred}
          </button>
        </div>

        {scanner.isError ? (
          <ErrorBlock message={t.empty} onRetry={() => scanner.refetch()} retry={t.retry} />
        ) : scanner.isLoading ? (
          <div className="mb-6 grid grid-cols-2 gap-2 sm:grid-cols-4 lg:grid-cols-6">
            {Array.from({ length: 8 }).map((_, i) => (
              <Skeleton key={i} className="h-24 rounded-2xl" />
            ))}
          </div>
        ) : rows.length === 0 ? (
          <p className="mb-6 text-sm text-muted-foreground">{starredOnly ? t.noStar : t.empty}</p>
        ) : (
          <div className="mb-6 grid grid-cols-2 gap-2 sm:grid-cols-3 lg:grid-cols-6">
            {rows.map((row) => (
              <ScannerCard
                key={row.id}
                row={row}
                lang={lang}
                active={row.id === selectedId}
                onSelect={() => setSelectedId(row.id)}
              />
            ))}
          </div>
        )}

        {detail.isError ? (
          <ErrorBlock
            message={lang === "bn" ? "এই মার্কেটের ডেটা আসেনি।" : "Could not load this market."}
            onRetry={() => detail.refetch()}
            retry={t.retry}
          />
        ) : detail.isLoading || !detail.data || !asset ? (
          <div className="grid gap-3 lg:grid-cols-5">
            <Skeleton className="h-80 rounded-3xl lg:col-span-3" />
            <Skeleton className="h-80 rounded-3xl lg:col-span-2" />
          </div>
        ) : (
          <Detail
            assetName={lang === "bn" ? asset.nameBn : asset.name}
            symbol={asset.symbol}
            data={detail.data}
            t={t}
            lang={lang}
            interval={interval}
            starred={starred}
            onToggleStar={() => {
              toggleWatch(selectedId);
              toast(starred ? (lang === "bn" ? "ওয়াচলিস্ট থেকে সরানো" : "Removed from watchlist") : t.watch);
            }}
            onRefresh={() => {
              void detail.refetch();
              void scanner.refetch();
            }}
          />
        )}
      </main>
    </div>
  );
}

function ScannerCard({
  row,
  lang,
  active,
  onSelect,
}: {
  row: ScannerRow;
  lang: Lang;
  active: boolean;
  onSelect: () => void;
}) {
  const asset = ASSET_BY_ID[row.id];
  const t = copy[lang];
  const tone = actionTone(row.action);
  const up = row.change24h >= 0;
  return (
    <button
      type="button"
      onClick={onSelect}
      className={cn(
        "rounded-2xl bg-card p-3 text-left shadow-border transition-[box-shadow,transform] duration-[var(--motion-quick)]",
        active && "shadow-border-hover ring-1 ring-primary/40",
      )}
    >
      <div className="flex items-center justify-between gap-1">
        <span className="font-mono text-xs text-muted-foreground">{asset?.symbol}</span>
        <Badge tone={tone}>{actionLabel(row.action, t)}</Badge>
      </div>
      <p className="mt-2 truncate text-sm font-medium">{lang === "bn" ? asset?.nameBn : asset?.name}</p>
      <p className="mt-1 font-mono text-sm tabular-nums">{formatPrice(row.price)}</p>
      <p className={cn("font-mono text-xs tabular-nums", up ? "text-buy" : "text-sell")}>{formatPct(row.change24h)}</p>
    </button>
  );
}

function Detail({
  assetName,
  symbol,
  data,
  t,
  lang,
  interval,
  starred,
  onToggleStar,
  onRefresh,
}: {
  assetName: string;
  symbol: string;
  data: AssetSignalDto;
  t: (typeof copy)[Lang];
  lang: Lang;
  interval: Interval;
  starred: boolean;
  onToggleStar: () => void;
  onRefresh: () => void;
}) {
  const tone = actionTone(data.action);
  const hero = heroLabel(data.action, t);
  const up = data.change24h >= 0;
  const bias =
    data.score >= 60 ? t.up : data.score <= 40 ? t.down : t.sideways;
  const ind = data.indicators;

  return (
    <div className="grid min-w-0 gap-3 lg:grid-cols-5">
      <section className="order-2 rounded-3xl bg-card p-4 shadow-border sm:p-5 lg:order-1 lg:col-span-3">
        <div className="flex items-start justify-between gap-3">
          <div>
            <p className="font-mono text-xs text-muted-foreground">{symbol}</p>
            <h1 className="text-xl font-semibold tracking-tight sm:text-2xl">{assetName}</h1>
            <p className="mt-1 font-mono text-2xl tabular-nums">{formatPrice(data.price)}</p>
            <p className={cn("font-mono text-sm tabular-nums", up ? "text-buy" : "text-sell")}>
              {formatPct(data.change24h)} · {data.intervalUsed ?? interval}
            </p>
          </div>
          <div className="flex gap-1">
            <Button variant="ghost" size="icon" onClick={onToggleStar} aria-label={t.watch}>
              <Star className={cn("size-4", starred && "fill-primary text-primary")} />
            </Button>
            <Button variant="ghost" size="icon" onClick={onRefresh} aria-label={t.lastUpdate}>
              <RefreshCw className="size-4" />
            </Button>
          </div>
        </div>
        <p className="mt-4 text-xs text-muted-foreground">
          {t.chart} · EMA 9 / 21
        </p>
        <PriceChart candles={data.candles} lang={lang} />
      </section>

      <section className="order-1 flex flex-col rounded-3xl bg-card p-4 shadow-border sm:p-5 lg:order-2 lg:col-span-2">
        <p
          className={cn(
            "text-4xl font-semibold tracking-tight sm:text-5xl",
            tone === "buy" && "text-buy",
            tone === "sell" && "text-sell",
            tone === "hold" && "text-foreground",
          )}
        >
          {hero}
        </p>
        <p className="mt-1 text-sm text-muted-foreground">
          {actionLabel(data.action, t)} · {t.bias} {bias}
        </p>
        <div className="mt-4">
          <div className="mb-1 flex items-center justify-between text-xs text-muted-foreground">
            <span>{t.confidence}</span>
            <span className="font-mono tabular-nums">
              {data.confidence}% · {confLabel(data.confidence, t)}
            </span>
          </div>
          <div className="h-1.5 overflow-hidden rounded-full bg-elevated">
            <div
              className={cn(
                "h-full rounded-full",
                tone === "buy" && "bg-buy",
                tone === "sell" && "bg-sell",
                tone === "hold" && "bg-hold",
              )}
              style={{ width: `${data.confidence}%` }}
            />
          </div>
        </div>

        <div className="mt-5 grid grid-cols-2 gap-2">
          <PlanCell icon={Target} label={t.entry} value={formatPrice(data.plan.entry)} />
          <PlanCell icon={Shield} label={t.stop} value={data.plan.side === "none" ? "—" : formatPrice(data.plan.stop)} />
          <PlanCell icon={Activity} label={t.target} value={data.plan.side === "none" ? "—" : formatPrice(data.plan.target)} />
          <PlanCell
            icon={Clock3}
            label={t.holdFor}
            value={lang === "bn" ? data.plan.holdBn : data.plan.holdEn}
          />
        </div>
        <p className="mt-3 text-sm text-muted-foreground">
          {data.plan.side === "none"
            ? t.waitPlan
            : data.plan.side === "long"
              ? t.longPlan
              : t.shortPlan}
          {data.plan.side !== "none" ? ` · ${t.rr} 1 : ${data.plan.riskReward}` : null}
        </p>
        <p className="mt-auto pt-4 text-xs text-subtle">
          {t.asOf} {formatTime(data.asOf, lang)}
        </p>
      </section>

      <section className="order-3 rounded-3xl bg-card p-4 shadow-border sm:p-5 lg:col-span-3">
        <h2 className="mb-3 text-sm font-medium">{t.why}</h2>
        <ul className="space-y-2">
          {data.reasons.map((r, i) => (
            <li key={i} className="flex gap-2 text-sm leading-relaxed">
              {r.bias === "buy" ? (
                <TrendingUp className="mt-0.5 size-4 shrink-0 text-buy" />
              ) : r.bias === "sell" ? (
                <TrendingDown className="mt-0.5 size-4 shrink-0 text-sell" />
              ) : (
                <Activity className="mt-0.5 size-4 shrink-0 text-muted-foreground" />
              )}
              <span>{lang === "bn" ? r.bn : r.en}</span>
            </li>
          ))}
        </ul>
      </section>

      <section className="order-4 rounded-3xl bg-card p-4 shadow-border sm:p-5 lg:col-span-2">
        <h2 className="mb-3 text-sm font-medium">{t.indicators}</h2>
        <div className="space-y-3">
          <Meter label="RSI" value={ind.rsi} min={0} max={100} markLow={30} markHigh={70} />
          <Row label="MACD" value={ind.macd.toFixed(4)} hint={ind.macdHist >= 0 ? "bull" : "bear"} />
          <Row label="EMA 9 / 21 / 50" value={`${formatPrice(ind.ema9)} / ${formatPrice(ind.ema21)}`} />
          <Row label="Stoch" value={`${ind.stochK.toFixed(0)} / ${ind.stochD.toFixed(0)}`} />
          <Row label={t.volume} value={`${ind.volumeRatio.toFixed(1)}×`} />
        </div>
      </section>
    </div>
  );
}

function PlanCell({
  icon: Icon,
  label,
  value,
}: {
  icon: typeof Target;
  label: string;
  value: string;
}) {
  return (
    <div className="rounded-xl bg-elevated px-3 py-2.5">
      <p className="flex items-center gap-1.5 text-xs text-muted-foreground">
        <Icon className="size-3.5" />
        {label}
      </p>
      <p className="mt-1 font-mono text-sm tabular-nums">{value}</p>
    </div>
  );
}

function Meter({
  label,
  value,
  min,
  max,
  markLow,
  markHigh,
}: {
  label: string;
  value: number;
  min: number;
  max: number;
  markLow: number;
  markHigh: number;
}) {
  const pct = Math.max(0, Math.min(100, ((value - min) / (max - min)) * 100));
  const tone = value <= markLow ? "bg-buy" : value >= markHigh ? "bg-sell" : "bg-primary";
  return (
    <div>
      <div className="mb-1 flex justify-between text-xs">
        <span className="text-muted-foreground">{label}</span>
        <span className="font-mono tabular-nums">{value.toFixed(1)}</span>
      </div>
      <div className="relative h-1.5 overflow-hidden rounded-full bg-elevated">
        <div className={cn("h-full rounded-full", tone)} style={{ width: `${pct}%` }} />
      </div>
    </div>
  );
}

function Row({ label, value, hint }: { label: string; value: string; hint?: "bull" | "bear" }) {
  return (
    <div className="flex items-center justify-between gap-3 text-sm">
      <span className="text-muted-foreground">{label}</span>
      <span className={cn("font-mono tabular-nums", hint === "bull" && "text-buy", hint === "bear" && "text-sell")}>
        {value}
      </span>
    </div>
  );
}

function ErrorBlock({ message, onRetry, retry }: { message: string; onRetry: () => void; retry: string }) {
  return (
    <div className="mb-6 rounded-2xl bg-card px-4 py-6 text-center shadow-border">
      <p className="text-sm text-muted-foreground">{message}</p>
      <Button className="mt-3" variant="outline" onClick={onRetry}>
        {retry}
      </Button>
    </div>
  );
}

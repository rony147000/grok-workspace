import {
  Area,
  CartesianGrid,
  ComposedChart,
  Line,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from "recharts";
import type { Lang } from "@/lib/i18n";
import { formatPrice, formatTime } from "@/lib/utils";
import type { ChartPoint } from "@/lib/ta";

function ChartTip({
  active,
  payload,
  lang,
}: {
  active?: boolean;
  payload?: Array<{ payload: ChartPoint }>;
  lang: Lang;
}) {
  if (!active || !payload?.[0]) return null;
  const p = payload[0].payload;
  return (
    <div className="rounded-lg bg-elevated px-3 py-2 text-xs shadow-border">
      <p className="mb-1 text-muted-foreground">{formatTime(p.t, lang)}</p>
      <p className="font-mono tabular-nums text-foreground">{formatPrice(p.c)}</p>
    </div>
  );
}

export function PriceChart({ candles, lang }: { candles: ChartPoint[]; lang: Lang }) {
  if (!candles.length) return null;
  const prices = candles.flatMap((c) => [c.c, c.ema9, c.ema21].filter((n): n is number => n != null));
  const min = Math.min(...prices);
  const max = Math.max(...prices);
  const pad = (max - min) * 0.08 || 1;
  const span = candles[candles.length - 1]!.t - candles[0]!.t;
  const daily = span > 3 * 24 * 60 * 60 * 1000;
  const loc = lang === "bn" ? "bn-BD" : "en-US";

  return (
    <div className="h-52 w-full min-w-0 overflow-hidden sm:h-64">
      <ResponsiveContainer width="100%" height="100%">
        <ComposedChart data={candles} margin={{ top: 8, right: 4, bottom: 0, left: 0 }}>
          <defs>
            <linearGradient id="priceFill" x1="0" y1="0" x2="0" y2="1">
              <stop offset="0%" stopColor="var(--color-primary)" stopOpacity={0.16} />
              <stop offset="100%" stopColor="var(--color-primary)" stopOpacity={0} />
            </linearGradient>
          </defs>
          <CartesianGrid vertical={false} stroke="var(--color-border)" />
          <XAxis
            dataKey="t"
            tickFormatter={(t) => {
              const d = new Date(t as number);
              return daily
                ? d.toLocaleDateString(loc, { month: "short", day: "numeric" })
                : d.toLocaleTimeString(loc, { hour: "2-digit", minute: "2-digit" });
            }}
            tick={{ fill: "var(--color-muted-foreground)", fontSize: 11 }}
            axisLine={false}
            tickLine={false}
            minTickGap={28}
          />
          <YAxis
            domain={[min - pad, max + pad]}
            tickFormatter={(v) => formatPrice(v as number)}
            tick={{ fill: "var(--color-muted-foreground)", fontSize: 11 }}
            axisLine={false}
            tickLine={false}
            width={56}
            orientation="right"
          />
          <Tooltip content={<ChartTip lang={lang} />} />
          <Area type="monotone" dataKey="c" stroke="none" fill="url(#priceFill)" isAnimationActive={false} />
          <Line
            type="monotone"
            dataKey="c"
            stroke="var(--color-foreground)"
            strokeWidth={1.6}
            dot={false}
            isAnimationActive={false}
          />
          <Line
            type="monotone"
            dataKey="ema9"
            stroke="var(--color-buy)"
            strokeWidth={1.2}
            dot={false}
            connectNulls
            isAnimationActive={false}
          />
          <Line
            type="monotone"
            dataKey="ema21"
            stroke="var(--color-sell)"
            strokeWidth={1.2}
            dot={false}
            connectNulls
            isAnimationActive={false}
          />
        </ComposedChart>
      </ResponsiveContainer>
    </div>
  );
}

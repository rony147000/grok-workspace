import { create } from "zustand";
import { persist } from "zustand/middleware";
import type { Category, Interval } from "./market";
import type { Lang } from "./i18n";

type DeskState = {
  lang: Lang;
  category: Category;
  interval: Interval;
  selectedId: string;
  watchlist: string[];
  starredOnly: boolean;
  setLang: (lang: Lang) => void;
  setCategory: (category: Category) => void;
  setInterval: (interval: Interval) => void;
  setSelectedId: (id: string) => void;
  toggleWatch: (id: string) => void;
  setStarredOnly: (v: boolean) => void;
};

export const useDesk = create<DeskState>()(
  persist(
    (set, get) => ({
      lang: "bn",
      category: "crypto",
      interval: "1h",
      selectedId: "btc",
      watchlist: ["btc", "eth", "gold"],
      starredOnly: false,
      setLang: (lang) => set({ lang }),
      setCategory: (category) => set({ category }),
      setInterval: (interval) => set({ interval }),
      setSelectedId: (selectedId) => set({ selectedId }),
      toggleWatch: (id) => {
        const cur = get().watchlist;
        set({
          watchlist: cur.includes(id) ? cur.filter((x) => x !== id) : [...cur, id],
        });
      },
      setStarredOnly: (starredOnly) => set({ starredOnly }),
    }),
    {
      name: "nishan-desk",
      partialize: (s) => ({
        lang: s.lang,
        interval: s.interval,
        watchlist: s.watchlist,
      }),
    },
  ),
);

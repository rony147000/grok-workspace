import type { Interval } from "./market";

export type Candle = {
  t: number;
  o: number;
  h: number;
  l: number;
  c: number;
  v: number;
};

export type SignalAction = "strong_buy" | "buy" | "hold" | "sell" | "strong_sell";

export type Reason = { bias: "buy" | "sell" | "neutral"; bn: string; en: string };

export type IndicatorSnapshot = {
  rsi: number;
  macd: number;
  macdSignal: number;
  macdHist: number;
  ema9: number;
  ema21: number;
  ema50: number;
  bbUpper: number;
  bbMid: number;
  bbLower: number;
  stochK: number;
  stochD: number;
  atr: number;
  volumeRatio: number;
};

export type ChartPoint = Candle & {
  ema9: number | null;
  ema21: number | null;
  ema50: number | null;
  bbU: number | null;
  bbM: number | null;
  bbL: number | null;
};

export type TradePlan = {
  side: "long" | "short" | "none";
  entry: number;
  stop: number;
  target: number;
  riskReward: number;
  holdBn: string;
  holdEn: string;
};

export type ComputedSignal = {
  action: SignalAction;
  score: number;
  confidence: number;
  indicators: IndicatorSnapshot;
  reasons: Reason[];
  plan: TradePlan;
  candles: ChartPoint[];
};

function lastNum(xs: Array<number | null>): number | null {
  for (let i = xs.length - 1; i >= 0; i--) {
    const v = xs[i];
    if (v != null && Number.isFinite(v)) return v;
  }
  return null;
}

export function sma(values: number[], period: number): Array<number | null> {
  const out: Array<number | null> = Array(values.length).fill(null);
  if (period <= 0) return out;
  let sum = 0;
  for (let i = 0; i < values.length; i++) {
    sum += values[i]!;
    if (i >= period) sum -= values[i - period]!;
    if (i >= period - 1) out[i] = sum / period;
  }
  return out;
}

export function ema(values: number[], period: number): Array<number | null> {
  const out: Array<number | null> = Array(values.length).fill(null);
  if (values.length < period) return out;
  const k = 2 / (period + 1);
  let prev = 0;
  for (let i = 0; i < period; i++) prev += values[i]!;
  prev /= period;
  out[period - 1] = prev;
  for (let i = period; i < values.length; i++) {
    prev = values[i]! * k + prev * (1 - k);
    out[i] = prev;
  }
  return out;
}

export function rsi(closes: number[], period = 14): Array<number | null> {
  const out: Array<number | null> = Array(closes.length).fill(null);
  if (closes.length < period + 1) return out;
  let gain = 0;
  let loss = 0;
  for (let i = 1; i <= period; i++) {
    const d = closes[i]! - closes[i - 1]!;
    if (d >= 0) gain += d;
    else loss -= d;
  }
  let avgGain = gain / period;
  let avgLoss = loss / period;
  out[period] = avgLoss === 0 ? 100 : 100 - 100 / (1 + avgGain / avgLoss);
  for (let i = period + 1; i < closes.length; i++) {
    const d = closes[i]! - closes[i - 1]!;
    const g = d > 0 ? d : 0;
    const l = d < 0 ? -d : 0;
    avgGain = (avgGain * (period - 1) + g) / period;
    avgLoss = (avgLoss * (period - 1) + l) / period;
    out[i] = avgLoss === 0 ? 100 : 100 - 100 / (1 + avgGain / avgLoss);
  }
  return out;
}

function stdev(window: number[]): number {
  const m = window.reduce((a, b) => a + b, 0) / window.length;
  const v = window.reduce((a, b) => a + (b - m) ** 2, 0) / window.length;
  return Math.sqrt(v);
}

export function bollinger(closes: number[], period = 20, mult = 2) {
  const mid = sma(closes, period);
  const upper: Array<number | null> = Array(closes.length).fill(null);
  const lower: Array<number | null> = Array(closes.length).fill(null);
  for (let i = period - 1; i < closes.length; i++) {
    const slice = closes.slice(i - period + 1, i + 1);
    const s = stdev(slice);
    const m = mid[i];
    if (m == null) continue;
    upper[i] = m + mult * s;
    lower[i] = m - mult * s;
  }
  return { mid, upper, lower };
}

export function macd(closes: number[]) {
  const e12 = ema(closes, 12);
  const e26 = ema(closes, 26);
  const line: Array<number | null> = closes.map((_, i) => {
    const a = e12[i];
    const b = e26[i];
    return a != null && b != null ? a - b : null;
  });
  const compact: number[] = [];
  const map: number[] = [];
  for (let i = 0; i < line.length; i++) {
    if (line[i] != null) {
      map.push(i);
      compact.push(line[i]!);
    }
  }
  const sigCompact = ema(compact, 9);
  const signal: Array<number | null> = Array(closes.length).fill(null);
  const hist: Array<number | null> = Array(closes.length).fill(null);
  for (let j = 0; j < compact.length; j++) {
    const i = map[j]!;
    const s = sigCompact[j];
    if (s == null) continue;
    signal[i] = s;
    hist[i] = compact[j]! - s;
  }
  return { line, signal, hist };
}

export function stochastic(candles: Candle[], kPeriod = 14, dPeriod = 3) {
  const k: Array<number | null> = Array(candles.length).fill(null);
  for (let i = kPeriod - 1; i < candles.length; i++) {
    let hh = -Infinity;
    let ll = Infinity;
    for (let j = i - kPeriod + 1; j <= i; j++) {
      hh = Math.max(hh, candles[j]!.h);
      ll = Math.min(ll, candles[j]!.l);
    }
    const den = hh - ll;
    k[i] = den === 0 ? 50 : ((candles[i]!.c - ll) / den) * 100;
  }
  const compact: number[] = [];
  const idx: number[] = [];
  for (let i = 0; i < k.length; i++) {
    if (k[i] != null) {
      idx.push(i);
      compact.push(k[i]!);
    }
  }
  const dCompact = sma(compact, dPeriod);
  const d: Array<number | null> = Array(candles.length).fill(null);
  for (let j = 0; j < compact.length; j++) {
    const i = idx[j]!;
    d[i] = dCompact[j] ?? null;
  }
  return { k, d };
}

export function atr(candles: Candle[], period = 14): Array<number | null> {
  const tr: number[] = [];
  for (let i = 0; i < candles.length; i++) {
    const c = candles[i]!;
    if (i === 0) {
      tr.push(c.h - c.l);
      continue;
    }
    const prev = candles[i - 1]!.c;
    tr.push(Math.max(c.h - c.l, Math.abs(c.h - prev), Math.abs(c.l - prev)));
  }
  const out: Array<number | null> = Array(candles.length).fill(null);
  if (tr.length < period) return out;
  let prev = 0;
  for (let i = 0; i < period; i++) prev += tr[i]!;
  prev /= period;
  out[period - 1] = prev;
  for (let i = period; i < tr.length; i++) {
    prev = (prev * (period - 1) + tr[i]!) / period;
    out[i] = prev;
  }
  return out;
}

function holdCopy(interval: Interval, kind: "trend" | "reversion"): { bn: string; en: string } {
  const map = {
    "15m": {
      trend: { bn: "৮–২৪ ঘণ্টা", en: "8–24 hours" },
      reversion: { bn: "২–৮ ঘণ্টা", en: "2–8 hours" },
    },
    "1h": {
      trend: { bn: "১–৪ দিন", en: "1–4 days" },
      reversion: { bn: "৮–২৪ ঘণ্টা", en: "8–24 hours" },
    },
    "4h": {
      trend: { bn: "১–২ সপ্তাহ", en: "1–2 weeks" },
      reversion: { bn: "১–৫ দিন", en: "1–5 days" },
    },
    "1d": {
      trend: { bn: "৩–৮ সপ্তাহ", en: "3–8 weeks" },
      reversion: { bn: "১–৩ সপ্তাহ", en: "1–3 weeks" },
    },
  } as const;
  return map[interval][kind];
}

function actionFromScore(score: number): SignalAction {
  if (score >= 74) return "strong_buy";
  if (score >= 60) return "buy";
  if (score <= 26) return "strong_sell";
  if (score <= 40) return "sell";
  return "hold";
}

export function computeSignal(candles: Candle[], interval: Interval): ComputedSignal | null {
  if (candles.length < 60) return null;
  const closes = candles.map((c) => c.c);
  const volumes = candles.map((c) => c.v);
  const ema9 = ema(closes, 9);
  const ema21 = ema(closes, 21);
  const ema50 = ema(closes, 50);
  const rsiV = rsi(closes, 14);
  const macdV = macd(closes);
  const bb = bollinger(closes, 20, 2);
  const stoch = stochastic(candles, 14, 3);
  const atrV = atr(candles, 14);
  const volSma = sma(volumes, 20);

  const price = closes[closes.length - 1]!;
  const e9 = lastNum(ema9);
  const e21 = lastNum(ema21);
  const e50 = lastNum(ema50);
  const r = lastNum(rsiV);
  const mLine = lastNum(macdV.line);
  const mSig = lastNum(macdV.signal);
  const mHist = lastNum(macdV.hist);
  const prevHist = macdV.hist.length > 2 ? macdV.hist[macdV.hist.length - 2] : null;
  const bbU = lastNum(bb.upper);
  const bbM = lastNum(bb.mid);
  const bbL = lastNum(bb.lower);
  const k = lastNum(stoch.k);
  const d = lastNum(stoch.d);
  const a = lastNum(atrV);
  const vAvg = lastNum(volSma);
  const lastVol = volumes[volumes.length - 1] ?? 0;
  const volumeRatio = vAvg && vAvg > 0 ? lastVol / vAvg : 1;

  if (
    e9 == null ||
    e21 == null ||
    e50 == null ||
    r == null ||
    mLine == null ||
    mSig == null ||
    mHist == null ||
    bbU == null ||
    bbM == null ||
    bbL == null ||
    k == null ||
    d == null ||
    a == null
  ) {
    return null;
  }

  let score = 50;
  const reasons: Reason[] = [];
  let votes = 0;
  let aligned = 0;

  const bump = (delta: number, reason: Reason | null) => {
    score += delta;
    votes += 1;
    if (delta > 0) aligned += 1;
    if (reason) reasons.push(reason);
  };

  if (e9 > e21) {
    bump(8, { bias: "buy", bn: "EMA ৯, EMA ২১ এর উপরে — স্বল্পমেয়াদি আপট্রেন্ড", en: "EMA 9 is above EMA 21 — short-term uptrend" });
  } else {
    bump(-8, { bias: "sell", bn: "EMA ৯, EMA ২১ এর নিচে — স্বল্পমেয়াদি ডাউনট্রেন্ড", en: "EMA 9 is below EMA 21 — short-term downtrend" });
  }

  if (e21 > e50) {
    bump(7, { bias: "buy", bn: "EMA ২১, EMA ৫০ এর উপরে — মাঝারি ট্রেন্ড পজিটিভ", en: "EMA 21 is above EMA 50 — medium trend is up" });
  } else {
    bump(-7, { bias: "sell", bn: "EMA ২১, EMA ৫০ এর নিচে — মাঝারি ট্রেন্ড নেগেটিভ", en: "EMA 21 is below EMA 50 — medium trend is down" });
  }

  if (price > e9) bump(4, null);
  else bump(-4, null);

  if (r < 30) {
    bump(12, { bias: "buy", bn: `RSI ${r.toFixed(0)} — ওভারসোল্ড, বাউন্সের সম্ভাবনা`, en: `RSI ${r.toFixed(0)} — oversold, bounce is more likely` });
  } else if (r > 70) {
    bump(-12, { bias: "sell", bn: `RSI ${r.toFixed(0)} — ওভারবট, কারেকশনের সম্ভাবনা`, en: `RSI ${r.toFixed(0)} — overbought, a pullback is more likely` });
  } else if (r >= 52 && r <= 68) {
    bump(4, { bias: "buy", bn: `RSI ${r.toFixed(0)} — বুলিশ জোনে`, en: `RSI ${r.toFixed(0)} — in a bullish zone` });
  } else if (r <= 48 && r >= 32) {
    bump(-4, { bias: "sell", bn: `RSI ${r.toFixed(0)} — বেয়ারিশ জোনে`, en: `RSI ${r.toFixed(0)} — in a bearish zone` });
  } else {
    bump(0, { bias: "neutral", bn: `RSI ${r.toFixed(0)} — নিউট্রাল`, en: `RSI ${r.toFixed(0)} — neutral` });
  }

  if (mLine > mSig) {
    bump(9, { bias: "buy", bn: "MACD সিগনাল লাইনের উপরে", en: "MACD is above its signal line" });
  } else {
    bump(-9, { bias: "sell", bn: "MACD সিগনাল লাইনের নিচে", en: "MACD is below its signal line" });
  }

  if (prevHist != null) {
    if (mHist > prevHist && mHist > 0) bump(4, null);
    else if (mHist < prevHist && mHist < 0) bump(-4, null);
  }

  if (price < bbL) {
    bump(9, { bias: "buy", bn: "দাম বলিঞ্জার লোয়ার ব্যান্ডের নিচে — এক্সট্রিম", en: "Price is below the lower Bollinger band — stretched down" });
  } else if (price > bbU) {
    bump(-9, { bias: "sell", bn: "দাম বলিঞ্জার আপার ব্যান্ডের উপরে — এক্সট্রিম", en: "Price is above the upper Bollinger band — stretched up" });
  } else if (price > bbM) {
    bump(3, null);
  } else {
    bump(-3, null);
  }

  if (k < 20) {
    bump(8, { bias: "buy", bn: `স্টোকাস্টিক ${k.toFixed(0)} — ওভারসোল্ড`, en: `Stochastic ${k.toFixed(0)} — oversold` });
  } else if (k > 80) {
    bump(-8, { bias: "sell", bn: `স্টোকাস্টিক ${k.toFixed(0)} — ওভারবট`, en: `Stochastic ${k.toFixed(0)} — overbought` });
  } else if (k > d) {
    bump(3, null);
  } else {
    bump(-3, null);
  }

  const last = candles[candles.length - 1]!;
  const upBar = last.c >= last.o;
  if (volumeRatio >= 1.4) {
    if (upBar) {
      bump(6, { bias: "buy", bn: `ভলিউম ${volumeRatio.toFixed(1)}× গড় — আপসাইড কনফার্ম`, en: `Volume ${volumeRatio.toFixed(1)}× average — upside confirmation` });
    } else {
      bump(-6, { bias: "sell", bn: `ভলিউম ${volumeRatio.toFixed(1)}× গড় — ডাউনসাইড কনফার্ম`, en: `Volume ${volumeRatio.toFixed(1)}× average — downside confirmation` });
    }
  }

  score = Math.max(0, Math.min(100, Math.round(score)));
  const action = actionFromScore(score);
  const lean = Math.abs(score - 50);
  const agreement = votes > 0 ? aligned / votes : 0.5;
  const confidence = Math.max(18, Math.min(92, Math.round(lean * 1.35 + agreement * 28)));

  const kind: "trend" | "reversion" = (r < 32 || r > 68) && Math.abs(e9 - e21) / price < 0.008 ? "reversion" : "trend";
  const hold = holdCopy(interval, kind);

  let side: TradePlan["side"] = "none";
  if (action === "buy" || action === "strong_buy") side = "long";
  if (action === "sell" || action === "strong_sell") side = "short";

  const stopDist = a * 1.5;
  const tgtDist = a * 2.4;
  let stop = price;
  let target = price;
  if (side === "long") {
    stop = price - stopDist;
    target = price + tgtDist;
  } else if (side === "short") {
    stop = price + stopDist;
    target = price - tgtDist;
  }
  const rr = stopDist > 0 ? tgtDist / stopDist : 0;

  const sliceFrom = Math.max(0, candles.length - 80);
  const chart: ChartPoint[] = candles.slice(sliceFrom).map((c, i) => {
    const idx = sliceFrom + i;
    return {
      ...c,
      ema9: ema9[idx] ?? null,
      ema21: ema21[idx] ?? null,
      ema50: ema50[idx] ?? null,
      bbU: bb.upper[idx] ?? null,
      bbM: bb.mid[idx] ?? null,
      bbL: bb.lower[idx] ?? null,
    };
  });

  const topReasons = reasons
    .filter((x) => x.bias !== "neutral")
    .slice(0, 4)
    .concat(reasons.filter((x) => x.bias === "neutral").slice(0, 1))
    .slice(0, 4);

  return {
    action,
    score,
    confidence,
    indicators: {
      rsi: r,
      macd: mLine,
      macdSignal: mSig,
      macdHist: mHist,
      ema9: e9,
      ema21: e21,
      ema50: e50,
      bbUpper: bbU,
      bbMid: bbM,
      bbLower: bbL,
      stochK: k,
      stochD: d,
      atr: a,
      volumeRatio,
    },
    reasons: topReasons,
    plan: {
      side,
      entry: price,
      stop,
      target,
      riskReward: Math.round(rr * 100) / 100,
      holdBn: hold.bn,
      holdEn: hold.en,
    },
    candles: chart,
  };
}

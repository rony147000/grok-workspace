import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { ASSET_BY_ID, assetsIn, type Asset, type Category, type Interval } from "./market";
import { computeSignal, type Candle, type SignalAction } from "./ta";

const UA =
  "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36";

const cache = new Map<string, { at: number; value: unknown }>();

async function cached<T>(key: string, ttlMs: number, fn: () => Promise<T>): Promise<T> {
  const hit = cache.get(key);
  if (hit && Date.now() - hit.at < ttlMs) return hit.value as T;
  const value = await fn();
  cache.set(key, { at: Date.now(), value });
  return value;
}

async function fetchJson(url: string, extraHeaders?: Record<string, string>): Promise<unknown> {
  const ctrl = new AbortController();
  const t = setTimeout(() => ctrl.abort(), 9000);
  try {
    const res = await fetch(url, {
      signal: ctrl.signal,
      headers: { Accept: "application/json", "User-Agent": UA, ...extraHeaders },
    });
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    return await res.json();
  } finally {
    clearTimeout(t);
  }
}

async function mapPool<T, R>(items: T[], limit: number, fn: (item: T) => Promise<R>): Promise<R[]> {
  const out: R[] = new Array(items.length);
  let cursor = 0;
  async function worker() {
    while (cursor < items.length) {
      const i = cursor++;
      out[i] = await fn(items[i]!);
    }
  }
  const n = Math.min(limit, items.length);
  await Promise.all(Array.from({ length: n }, () => worker()));
  return out;
}

function toNum(v: unknown): number {
  const n = typeof v === "number" ? v : Number(v);
  return Number.isFinite(n) ? n : NaN;
}

function parseBinanceKlines(raw: unknown): Candle[] {
  if (!Array.isArray(raw)) return [];
  const out: Candle[] = [];
  for (const row of raw) {
    if (!Array.isArray(row) || row.length < 6) continue;
    const t = toNum(row[0]);
    const o = toNum(row[1]);
    const h = toNum(row[2]);
    const l = toNum(row[3]);
    const c = toNum(row[4]);
    const v = toNum(row[5]);
    if ([t, o, h, l, c].every(Number.isFinite)) out.push({ t, o, h, l, c, v: Number.isFinite(v) ? v : 0 });
  }
  return out;
}

function parseYahooChart(raw: unknown): { candles: Candle[]; price: number; change24h: number } | null {
  const chart = (raw as { chart?: { result?: Array<Record<string, unknown>> } })?.chart;
  const result = chart?.result?.[0];
  if (!result) return null;
  const ts = result.timestamp as number[] | undefined;
  const quote = (result.indicators as { quote?: Array<Record<string, Array<number | null>>> })?.quote?.[0];
  if (!ts || !quote) return null;
  const candles: Candle[] = [];
  for (let i = 0; i < ts.length; i++) {
    const o = quote.open?.[i];
    const h = quote.high?.[i];
    const l = quote.low?.[i];
    const c = quote.close?.[i];
    const v = quote.volume?.[i];
    if (o == null || h == null || l == null || c == null) continue;
    if (![o, h, l, c].every(Number.isFinite)) continue;
    candles.push({ t: ts[i]! * 1000, o, h, l, c, v: v ?? 0 });
  }
  const meta = result.meta as { regularMarketPrice?: number; chartPreviousClose?: number; previousClose?: number } | undefined;
  const price = meta?.regularMarketPrice ?? candles.at(-1)?.c ?? NaN;
  const prev = meta?.chartPreviousClose ?? meta?.previousClose;
  const change24h = prev && prev !== 0 ? ((price - prev) / prev) * 100 : 0;
  return { candles, price, change24h };
}

function resample4h(hourly: Candle[]): Candle[] {
  const groups = new Map<number, Candle[]>();
  const step = 4 * 60 * 60 * 1000;
  for (const c of hourly) {
    const key = Math.floor(c.t / step) * step;
    const list = groups.get(key);
    if (list) list.push(c);
    else groups.set(key, [c]);
  }
  const out: Candle[] = [];
  for (const [t, list] of groups) {
    if (!list.length) continue;
    out.push({
      t,
      o: list[0]!.o,
      h: Math.max(...list.map((x) => x.h)),
      l: Math.min(...list.map((x) => x.l)),
      c: list[list.length - 1]!.c,
      v: list.reduce((s, x) => s + x.v, 0),
    });
  }
  return out.sort((a, b) => a.t - b.t);
}

const BINANCE_INTERVAL: Record<Interval, string> = {
  "15m": "15m",
  "1h": "1h",
  "4h": "4h",
  "1d": "1d",
};

async function fetchBinanceKlines(symbol: string, interval: Interval): Promise<Candle[]> {
  const url = `https://data-api.binance.vision/api/v3/klines?symbol=${encodeURIComponent(symbol)}&interval=${BINANCE_INTERVAL[interval]}&limit=180`;
  return cached(`bn:k:${symbol}:${interval}`, 25_000, async () => parseBinanceKlines(await fetchJson(url)));
}

type Ticker = { price: number; change24h: number };

async function fetchBinanceTickers(symbols: string[]): Promise<Record<string, Ticker>> {
  if (!symbols.length) return {};
  const encoded = encodeURIComponent(JSON.stringify(symbols));
  const url = `https://data-api.binance.vision/api/v3/ticker/24hr?symbols=${encoded}`;
  return cached(`bn:t:${symbols.join(",")}`, 20_000, async () => {
    const raw = await fetchJson(url);
    const rows = Array.isArray(raw) ? raw : [raw];
    const map: Record<string, Ticker> = {};
    for (const row of rows) {
      const r = row as { symbol?: string; lastPrice?: string; priceChangePercent?: string };
      if (!r.symbol) continue;
      map[r.symbol] = { price: toNum(r.lastPrice), change24h: toNum(r.priceChangePercent) };
    }
    return map;
  });
}

function yahooRange(interval: Interval): { interval: string; range: string; resample: boolean } {
  if (interval === "15m") return { interval: "15m", range: "10d", resample: false };
  if (interval === "1h") return { interval: "60m", range: "1mo", resample: false };
  if (interval === "4h") return { interval: "60m", range: "3mo", resample: true };
  return { interval: "1d", range: "1y", resample: false };
}

async function fetchYahoo(symbol: string, interval: Interval) {
  const spec = yahooRange(interval);
  const url = `https://query1.finance.yahoo.com/v8/finance/chart/${encodeURIComponent(symbol)}?interval=${spec.interval}&range=${spec.range}`;
  return cached(`yh:${symbol}:${interval}`, 40_000, async () => {
    let parsed = parseYahooChart(await fetchJson(url));
    if (!parsed) {
      const alt = url.replace("query1", "query2");
      parsed = parseYahooChart(await fetchJson(alt));
    }
    if (!parsed) throw new Error(`No Yahoo data for ${symbol}`);
    const candles = spec.resample ? resample4h(parsed.candles) : parsed.candles;
    return { ...parsed, candles, intervalUsed: interval as Interval };
  });
}

function nasdaqMoney(s: string): number {
  return Number(String(s).replace(/[$,]/g, ""));
}

function nasdaqDate(s: string): number {
  const [m, d, y] = s.split("/").map(Number);
  return Date.UTC(y!, (m ?? 1) - 1, d ?? 1, 20, 0, 0);
}

async function fetchNasdaqDaily(symbol: string): Promise<{
  candles: Candle[];
  price: number;
  change24h: number;
  intervalUsed: Interval;
}> {
  const today = new Date();
  const from = new Date(today);
  from.setUTCFullYear(from.getUTCFullYear() - 1);
  const fromdate = from.toISOString().slice(0, 10);
  const todate = today.toISOString().slice(0, 10);
  const url = `https://api.nasdaq.com/api/quote/${encodeURIComponent(symbol)}/historical?assetclass=stocks&fromdate=${fromdate}&todate=${todate}&limit=220`;
  return cached(`nq:${symbol}`, 60_000, async () => {
    const raw = await fetchJson(url, {
      Origin: "https://www.nasdaq.com",
      Referer: "https://www.nasdaq.com/",
    });
    const rows =
      (raw as { data?: { tradesTable?: { rows?: Array<Record<string, string>> } } })?.data?.tradesTable
        ?.rows ?? [];
    const candles: Candle[] = [];
    for (const row of rows) {
      const t = nasdaqDate(row.date ?? "");
      const o = nasdaqMoney(row.open ?? "");
      const h = nasdaqMoney(row.high ?? "");
      const l = nasdaqMoney(row.low ?? "");
      const c = nasdaqMoney(row.close ?? "");
      const v = nasdaqMoney(row.volume ?? "0");
      if ([t, o, h, l, c].every(Number.isFinite)) candles.push({ t, o, h, l, c, v });
    }
    candles.sort((a, b) => a.t - b.t);
    if (candles.length < 60) throw new Error(`Nasdaq short history for ${symbol}`);
    const price = candles.at(-1)!.c;
    const prev = candles.at(-2)?.c;
    const change24h = prev && prev !== 0 ? ((price - prev) / prev) * 100 : 0;
    return { candles, price, change24h, intervalUsed: "1d" as const };
  });
}

async function tryBinance(asset: Asset, interval: Interval) {
  if (!asset.binance) return null;
  const [candles, tickers] = await Promise.all([
    fetchBinanceKlines(asset.binance, interval),
    fetchBinanceTickers([asset.binance]),
  ]);
  if (!candles.length) return null;
  const tk = tickers[asset.binance];
  return {
    candles,
    price: tk?.price || candles.at(-1)?.c || NaN,
    change24h: tk?.change24h ?? 0,
    intervalUsed: interval,
  };
}

async function loadAsset(asset: Asset, interval: Interval): Promise<{
  candles: Candle[];
  price: number;
  change24h: number;
  intervalUsed: Interval;
} | null> {
  const attempts: Array<() => Promise<{
    candles: Candle[];
    price: number;
    change24h: number;
    intervalUsed: Interval;
  }>> = [];

  if (asset.venue === "binance" && asset.binance) {
    attempts.push(async () => {
      const r = await tryBinance(asset, interval);
      if (!r) throw new Error("binance empty");
      return r;
    });
  }
  if (asset.yahoo) {
    attempts.push(async () => fetchYahoo(asset.yahoo!, interval));
  }
  if (asset.category === "stock" && asset.yahoo) {
    attempts.push(async () => fetchNasdaqDaily(asset.yahoo!));
  }
  if (asset.venue === "yahoo" && asset.binance) {
    attempts.push(async () => {
      const r = await tryBinance(asset, interval);
      if (!r) throw new Error("binance empty");
      return r;
    });
  }

  for (const run of attempts) {
    try {
      return await run();
    } catch {
      continue;
    }
  }
  return null;
}

export type ScannerRow = {
  id: string;
  price: number;
  change24h: number;
  action: SignalAction;
  score: number;
  confidence: number;
};

export type AssetSignalDto = ScannerRow & {
  indicators: NonNullable<ReturnType<typeof computeSignal>>["indicators"];
  reasons: NonNullable<ReturnType<typeof computeSignal>>["reasons"];
  plan: NonNullable<ReturnType<typeof computeSignal>>["plan"];
  candles: NonNullable<ReturnType<typeof computeSignal>>["candles"];
  asOf: number;
  intervalUsed: Interval;
};

const ScanInput = z.object({
  category: z.enum(["crypto", "stock", "metal", "fx"]),
  interval: z.enum(["15m", "1h", "4h", "1d"]),
});

const DetailInput = z.object({
  id: z.string(),
  interval: z.enum(["15m", "1h", "4h", "1d"]),
});

export const getScanner = createServerFn({ method: "POST" })
  .validator((d) => ScanInput.parse(d))
  .handler(async ({ data }) => {
    const list = assetsIn(data.category as Category);
    const rows = await mapPool(list, 4, async (asset) => {
      const loaded = await loadAsset(asset, data.interval as Interval);
      if (!loaded) return null;
      const sig = computeSignal(loaded.candles, loaded.intervalUsed);
      if (!sig) return null;
      const row: ScannerRow = {
        id: asset.id,
        price: loaded.price,
        change24h: loaded.change24h,
        action: sig.action,
        score: sig.score,
        confidence: sig.confidence,
      };
      return row;
    });
    return rows.filter((r): r is ScannerRow => r != null);
  });

export const getAssetSignal = createServerFn({ method: "POST" })
  .validator((d) => DetailInput.parse(d))
  .handler(async ({ data }) => {
    const asset = ASSET_BY_ID[data.id];
    if (!asset) throw new Error("Unknown market");
    const loaded = await loadAsset(asset, data.interval as Interval);
    if (!loaded) throw new Error("Market data unavailable");
    const sig = computeSignal(loaded.candles, loaded.intervalUsed);
    if (!sig) throw new Error("Not enough candles");
    const dto: AssetSignalDto = {
      id: asset.id,
      price: loaded.price,
      change24h: loaded.change24h,
      action: sig.action,
      score: sig.score,
      confidence: sig.confidence,
      indicators: sig.indicators,
      reasons: sig.reasons,
      plan: sig.plan,
      candles: sig.candles,
      asOf: Date.now(),
      intervalUsed: loaded.intervalUsed,
    };
    return dto;
  });

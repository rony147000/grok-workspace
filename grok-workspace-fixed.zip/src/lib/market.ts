export type Category = "crypto" | "stock" | "metal" | "fx";
export type Interval = "15m" | "1h" | "4h" | "1d";
export type Venue = "binance" | "yahoo";

export type Asset = {
  id: string;
  symbol: string;
  name: string;
  nameBn: string;
  category: Category;
  venue: Venue;
  binance?: string;
  yahoo?: string;
};

export const INTERVALS: Interval[] = ["15m", "1h", "4h", "1d"];

export const ASSETS: Asset[] = [
  { id: "btc", symbol: "BTC", name: "Bitcoin", nameBn: "বিটকয়েন", category: "crypto", venue: "binance", binance: "BTCUSDT", yahoo: "BTC-USD" },
  { id: "eth", symbol: "ETH", name: "Ethereum", nameBn: "ইথেরিয়াম", category: "crypto", venue: "binance", binance: "ETHUSDT", yahoo: "ETH-USD" },
  { id: "bnb", symbol: "BNB", name: "BNB", nameBn: "বিএনবি", category: "crypto", venue: "binance", binance: "BNBUSDT", yahoo: "BNB-USD" },
  { id: "sol", symbol: "SOL", name: "Solana", nameBn: "সোলানা", category: "crypto", venue: "binance", binance: "SOLUSDT", yahoo: "SOL-USD" },
  { id: "xrp", symbol: "XRP", name: "XRP", nameBn: "এক্সআরপি", category: "crypto", venue: "binance", binance: "XRPUSDT", yahoo: "XRP-USD" },
  { id: "doge", symbol: "DOGE", name: "Dogecoin", nameBn: "ডোজকয়েন", category: "crypto", venue: "binance", binance: "DOGEUSDT", yahoo: "DOGE-USD" },
  { id: "ada", symbol: "ADA", name: "Cardano", nameBn: "কার্ডানো", category: "crypto", venue: "binance", binance: "ADAUSDT", yahoo: "ADA-USD" },
  { id: "avax", symbol: "AVAX", name: "Avalanche", nameBn: "অ্যাভালাঞ্চ", category: "crypto", venue: "binance", binance: "AVAXUSDT", yahoo: "AVAX-USD" },
  { id: "link", symbol: "LINK", name: "Chainlink", nameBn: "চেইনলিংক", category: "crypto", venue: "binance", binance: "LINKUSDT", yahoo: "LINK-USD" },
  { id: "sui", symbol: "SUI", name: "Sui", nameBn: "সুই", category: "crypto", venue: "binance", binance: "SUIUSDT", yahoo: "SUI-USD" },
  { id: "ton", symbol: "TON", name: "Toncoin", nameBn: "টনকয়েন", category: "crypto", venue: "binance", binance: "TONUSDT", yahoo: "TON-USD" },
  { id: "ltc", symbol: "LTC", name: "Litecoin", nameBn: "লাইটকয়েন", category: "crypto", venue: "binance", binance: "LTCUSDT", yahoo: "LTC-USD" },
  { id: "aapl", symbol: "AAPL", name: "Apple", nameBn: "অ্যাপল", category: "stock", venue: "yahoo", yahoo: "AAPL" },
  { id: "nvda", symbol: "NVDA", name: "Nvidia", nameBn: "এনভিডিয়া", category: "stock", venue: "yahoo", yahoo: "NVDA" },
  { id: "tsla", symbol: "TSLA", name: "Tesla", nameBn: "টেসলা", category: "stock", venue: "yahoo", yahoo: "TSLA" },
  { id: "msft", symbol: "MSFT", name: "Microsoft", nameBn: "মাইক্রোসফট", category: "stock", venue: "yahoo", yahoo: "MSFT" },
  { id: "amzn", symbol: "AMZN", name: "Amazon", nameBn: "অ্যামাজন", category: "stock", venue: "yahoo", yahoo: "AMZN" },
  { id: "googl", symbol: "GOOGL", name: "Alphabet", nameBn: "অ্যালফাবেট", category: "stock", venue: "yahoo", yahoo: "GOOGL" },
  { id: "meta", symbol: "META", name: "Meta", nameBn: "মেটা", category: "stock", venue: "yahoo", yahoo: "META" },
  { id: "nflx", symbol: "NFLX", name: "Netflix", nameBn: "নেটফ্লিক্স", category: "stock", venue: "yahoo", yahoo: "NFLX" },
  { id: "gold", symbol: "XAU", name: "Gold", nameBn: "সোনা", category: "metal", venue: "binance", yahoo: "GC=F", binance: "PAXGUSDT" },
  { id: "silver", symbol: "XAG", name: "Silver", nameBn: "রুপা", category: "metal", venue: "yahoo", yahoo: "SI=F" },
  { id: "eurusd", symbol: "EURUSD", name: "Euro / Dollar", nameBn: "ইউরো / ডলার", category: "fx", venue: "binance", yahoo: "EURUSD=X", binance: "EURUSDT" },
  { id: "gbpusd", symbol: "GBPUSD", name: "Pound / Dollar", nameBn: "পাউন্ড / ডলার", category: "fx", venue: "binance", yahoo: "GBPUSD=X", binance: "GBPUSDT" },
  { id: "audusd", symbol: "AUDUSD", name: "Aussie / Dollar", nameBn: "অজি / ডলার", category: "fx", venue: "binance", yahoo: "AUDUSD=X", binance: "AUDUSDT" },
];

export const ASSET_BY_ID = Object.fromEntries(ASSETS.map((a) => [a.id, a])) as Record<string, Asset>;

export function assetsIn(category: Category): Asset[] {
  return ASSETS.filter((a) => a.category === category);
}
